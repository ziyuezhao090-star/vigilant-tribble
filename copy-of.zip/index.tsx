
import React, { useState, useMemo, useRef, useEffect } from "react";
import { createRoot } from "react-dom/client";
import * as THREE from "three";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, OrbitControls, Sparkles, PerspectiveCamera } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette, Noise } from "@react-three/postprocessing";

// --- Configuration & Constants ---
const CONFIG = {
  NEEDLE_COUNT: 4500,
  ORNAMENT_COUNT: 500, 
  LIGHT_COUNT: 300, // New: Fairy lights for extra sparkle
  COLORS: {
    EMERALD: "#003b1f",
    EMERALD_LIGHT: "#006b3e",
    GOLD: "#ffcc00",
    GOLD_ROSE: "#ffaa77",
    METALLIC_GREEN: "#008542",
    LIGHT: "#fffec4", // Warm glowing light
    BACKGROUND: "#020202",
  },
  ANIMATION_SPEED: 2.0,
  TREE: {
    HEIGHT: 14,
    RADIUS_BOTTOM: 5.5,
  },
  SCATTER: {
    RADIUS: 25,
  }
};

// --- Helper Math ---
const randomVector = (r: number) => {
  const theta = Math.random() * Math.PI * 2;
  const phi = Math.acos(2 * Math.random() - 1);
  const x = r * Math.sin(phi) * Math.cos(theta);
  const y = r * Math.sin(phi) * Math.sin(theta);
  const z = r * Math.cos(phi);
  return new THREE.Vector3(x, y, z);
};

// --- Data Generation ---
type ItemData = {
  id: number;
  scatterPos: THREE.Vector3;
  treePos: THREE.Vector3;
  scatterRot: THREE.Euler;
  treeRot: THREE.Euler;
  scale: THREE.Vector3;
  color: THREE.Color;
  speed: number;
  emissiveIntensity?: number; // For lights
};

const useTreeData = (count: number, type: 'needle' | 'ornament' | 'light') => {
  return useMemo(() => {
    const data: ItemData[] = [];
    for (let i = 0; i < count; i++) {
      // 1. Tree Position (Cone Shape)
      const h = CONFIG.TREE.HEIGHT;
      const yNorm = Math.random(); 
      // Bias slightly to bottom for volume
      const y = (yNorm - 0.5) * h;
      
      const rBase = (1 - yNorm) * CONFIG.TREE.RADIUS_BOTTOM;
      const theta = (i * 2.39996); 
      
      let rNoise = rBase;
      if (type === 'needle') rNoise += (Math.random() - 0.5) * 1.5;
      else if (type === 'ornament') rNoise += (Math.random() - 0.5) * 0.8;
      else if (type === 'light') rNoise += (Math.random() - 0.2) * 0.5; // Lights stick close to surface

      const x = rNoise * Math.cos(theta);
      const z = rNoise * Math.sin(theta);
      const treePos = new THREE.Vector3(x, y, z);

      // 2. Scatter Position
      const scatterPos = randomVector(CONFIG.SCATTER.RADIUS);

      // 3. Rotations
      const treeRot = new THREE.Euler(
        (Math.random() - 0.5) + (type === 'needle' ? -Math.PI / 4 : 0), 
        Math.random() * Math.PI * 2, 
        (Math.random() - 0.5)
      );
      const scatterRot = new THREE.Euler(
        Math.random() * Math.PI, 
        Math.random() * Math.PI, 
        Math.random() * Math.PI
      );

      // 4. Scale & Color
      let scale = new THREE.Vector3(1, 1, 1);
      let color = new THREE.Color();
      let emissiveIntensity = 0;

      if (type === 'needle') {
         const s = 0.5 + Math.random() * 0.5;
         scale.set(0.05, 0.4 * s, 0.05);
         color.set(Math.random() > 0.5 ? CONFIG.COLORS.EMERALD : CONFIG.COLORS.EMERALD_LIGHT);
      } else if (type === 'ornament') {
         const s = 0.4 + Math.random() * 0.4;
         scale.set(s, s, s);
         const rand = Math.random();
         if (rand < 0.35) color.set(CONFIG.COLORS.GOLD);
         else if (rand < 0.65) color.set(CONFIG.COLORS.GOLD_ROSE);
         else color.set(CONFIG.COLORS.METALLIC_GREEN);
      } else if (type === 'light') {
         const s = 0.15 + Math.random() * 0.1;
         scale.set(s, s, s);
         color.set(CONFIG.COLORS.LIGHT);
         emissiveIntensity = 2.0 + Math.random() * 2.0;
      }

      data.push({
        id: i,
        treePos,
        scatterPos,
        treeRot,
        scatterRot,
        scale,
        color,
        speed: 0.5 + Math.random(),
        emissiveIntensity
      });
    }
    return data;
  }, [count, type]);
};

// --- Components ---

const Needles = ({ mode }: { mode: 'SCATTERED' | 'TREE_SHAPE' }) => {
  const data = useTreeData(CONFIG.NEEDLE_COUNT, 'needle');
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const tRef = useRef(0);
  
  useFrame((state, delta) => {
    if (!meshRef.current) return;
    const target = mode === 'TREE_SHAPE' ? 1 : 0;
    tRef.current = THREE.MathUtils.damp(tRef.current, target, CONFIG.ANIMATION_SPEED, delta);
    const t = tRef.current;
    const time = state.clock.elapsedTime;

    data.forEach((item, i) => {
      dummy.position.lerpVectors(item.scatterPos, item.treePos, t);
      if (t < 0.95) {
        dummy.position.y += Math.sin(time * item.speed + item.id) * 0.05 * (1-t);
        dummy.position.x += Math.cos(time * item.speed * 0.5 + item.id) * 0.05 * (1-t);
      }
      dummy.rotation.x = THREE.MathUtils.lerp(item.scatterRot.x, item.treeRot.x, t);
      dummy.rotation.y = THREE.MathUtils.lerp(item.scatterRot.y, item.treeRot.y, t);
      dummy.rotation.z = THREE.MathUtils.lerp(item.scatterRot.z, item.treeRot.z, t);
      if (t < 0.5) {
         dummy.rotation.x += time * 0.1 * item.speed;
         dummy.rotation.z += time * 0.05 * item.speed;
      }
      dummy.scale.copy(item.scale);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  useEffect(() => {
     if(meshRef.current) {
        data.forEach((item, i) => meshRef.current!.setColorAt(i, item.color));
        meshRef.current.instanceColor!.needsUpdate = true;
     }
  }, [data]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, CONFIG.NEEDLE_COUNT]} frustumCulled={false}>
      <coneGeometry args={[0.1, 1, 4]} />
      <meshStandardMaterial 
        roughness={0.3} // Shinier
        metalness={0.5}
        color={CONFIG.COLORS.EMERALD}
        emissive={CONFIG.COLORS.EMERALD}
        emissiveIntensity={0.1}
      />
    </instancedMesh>
  );
};

const Ornaments = ({ mode }: { mode: 'SCATTERED' | 'TREE_SHAPE' }) => {
  const data = useTreeData(CONFIG.ORNAMENT_COUNT, 'ornament');
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const tRef = useRef(0);

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    const target = mode === 'TREE_SHAPE' ? 1 : 0;
    tRef.current = THREE.MathUtils.damp(tRef.current, target, CONFIG.ANIMATION_SPEED * 0.8, delta);
    const t = tRef.current;
    const time = state.clock.elapsedTime;

    data.forEach((item, i) => {
      dummy.position.lerpVectors(item.scatterPos, item.treePos, t);
      if (t < 0.9) dummy.position.y += Math.sin(time * 0.5 + item.id) * 0.1 * (1-t);
      dummy.rotation.x = item.scatterRot.x + time * 0.2;
      dummy.rotation.y = item.scatterRot.y + time * 0.2;
      dummy.rotation.z = item.scatterRot.z;
      dummy.scale.copy(item.scale);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

   useEffect(() => {
     if(meshRef.current) {
        data.forEach((item, i) => meshRef.current!.setColorAt(i, item.color));
        meshRef.current.instanceColor!.needsUpdate = true;
     }
  }, [data]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, CONFIG.ORNAMENT_COUNT]} frustumCulled={false}>
      <sphereGeometry args={[0.7, 32, 32]} /> 
      <meshStandardMaterial 
        roughness={0.1} // Glossy
        metalness={0.9}
        envMapIntensity={3.0} // Very reflective
      />
    </instancedMesh>
  );
};

const FairyLights = ({ mode }: { mode: 'SCATTERED' | 'TREE_SHAPE' }) => {
  const data = useTreeData(CONFIG.LIGHT_COUNT, 'light');
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const tRef = useRef(0);

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    const target = mode === 'TREE_SHAPE' ? 1 : 0;
    tRef.current = THREE.MathUtils.damp(tRef.current, target, CONFIG.ANIMATION_SPEED * 0.9, delta);
    const t = tRef.current;
    const time = state.clock.elapsedTime;

    data.forEach((item, i) => {
      dummy.position.lerpVectors(item.scatterPos, item.treePos, t);
      // Gentle twinkle movement
      dummy.position.x += Math.sin(time * 2 + item.id) * 0.02 * t;
      dummy.position.z += Math.cos(time * 2 + item.id) * 0.02 * t;
      
      dummy.scale.copy(item.scale);
      // Twinkle size
      const blink = 0.8 + 0.4 * Math.sin(time * 3 + item.id * 10);
      dummy.scale.multiplyScalar(blink);
      
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  useEffect(() => {
     if(meshRef.current) {
        data.forEach((item, i) => meshRef.current!.setColorAt(i, item.color));
        meshRef.current.instanceColor!.needsUpdate = true;
     }
  }, [data]);

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, CONFIG.LIGHT_COUNT]} frustumCulled={false}>
      <sphereGeometry args={[0.5, 16, 16]} />
      <meshStandardMaterial 
        toneMapped={false}
        color={CONFIG.COLORS.LIGHT}
        emissive={CONFIG.COLORS.LIGHT}
        emissiveIntensity={4.0} // High glow
      />
    </instancedMesh>
  );
};

const Star = ({ mode }: { mode: 'SCATTERED' | 'TREE_SHAPE' }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const scatterPos = useMemo(() => randomVector(CONFIG.SCATTER.RADIUS), []);
  const treePos = useMemo(() => new THREE.Vector3(0, CONFIG.TREE.HEIGHT / 2 + 1.2, 0), []);
  const tRef = useRef(0);

  // Generate 5-point star shape
  const starShape = useMemo(() => {
    const shape = new THREE.Shape();
    const points = 5;
    const outerRadius = 1.2;
    const innerRadius = 0.5; 
    for(let i = 0; i < points * 2; i++) {
        // -PI/2 to start at top
        const angle = (i * Math.PI) / points - Math.PI / 2;
        const r = i % 2 === 0 ? outerRadius : innerRadius;
        const x = Math.cos(angle) * r;
        const y = Math.sin(angle) * r;
        if (i === 0) shape.moveTo(x, y);
        else shape.lineTo(x, y);
    }
    shape.closePath();
    return shape;
  }, []);

  const extrudeSettings = useMemo(() => ({
    depth: 0.5,
    bevelEnabled: true,
    bevelThickness: 0.1,
    bevelSize: 0.1,
    bevelSegments: 3
  }), []);

  useFrame((state, delta) => {
    if (!meshRef.current) return;
    const target = mode === 'TREE_SHAPE' ? 1 : 0;
    tRef.current = THREE.MathUtils.damp(tRef.current, target, CONFIG.ANIMATION_SPEED, delta);
    const t = tRef.current;
    
    meshRef.current.position.lerpVectors(scatterPos, treePos, t);
    
    // Spin animation
    meshRef.current.rotation.y += delta * 0.8;
    
    // Pulse
    const s = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.1;
    meshRef.current.scale.set(s, s, s);
  });

  return (
    <mesh ref={meshRef}>
      <extrudeGeometry args={[starShape, extrudeSettings]} />
      <meshStandardMaterial 
        color="#ffdd00"
        emissive="#ffdd00"
        emissiveIntensity={4.0}
        toneMapped={false}
        roughness={0.1}
        metalness={1}
      />
    </mesh>
  );
};

const Scene = ({ mode }: { mode: 'SCATTERED' | 'TREE_SHAPE' }) => {
  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 0, 32]} fov={50} />
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 2 - 0.5} 
        maxPolarAngle={Math.PI / 2 + 0.5} 
        autoRotate={mode === 'TREE_SHAPE'}
        autoRotateSpeed={0.5}
        maxDistance={40}
        minDistance={10}
      />
      
      <ambientLight intensity={0.1} />
      <directionalLight position={[10, 20, 10]} intensity={3} color="#fff0d0" />
      <pointLight position={[-10, 5, -10]} intensity={2} color="#00ffaa" />
      <Environment preset="city" />

      <Sparkles count={300} scale={35} size={5} speed={0.4} opacity={0.6} color="#fff8e0" />
      {mode === 'TREE_SHAPE' && (
        <Sparkles count={100} scale={12} size={3} speed={0.2} opacity={0.8} color="#ffff00" />
      )}

      <group rotation={[0, 0, 0]}>
         <Needles mode={mode} />
         <Ornaments mode={mode} />
         <FairyLights mode={mode} />
         <Star mode={mode} />
      </group>

      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.6} 
          mipmapBlur 
          intensity={2.0} // Increased bloom
          radius={0.5}
        />
        <Vignette eskil={false} offset={0.1} darkness={1.0} />
        <Noise opacity={0.02} />
      </EffectComposer>
    </>
  );
};

// --- Main App & UI ---

const App = () => {
  const [mode, setMode] = useState<'SCATTERED' | 'TREE_SHAPE'>('SCATTERED');

  const toggleMode = () => {
    setMode(prev => prev === 'SCATTERED' ? 'TREE_SHAPE' : 'SCATTERED');
  };

  return (
    <div style={{ width: "100vw", height: "100vh", position: "relative", backgroundColor: CONFIG.COLORS.BACKGROUND }}>
      <Canvas 
        dpr={[1, 2]} 
        gl={{ 
            antialias: false, 
            toneMapping: THREE.ACESFilmicToneMapping, 
            outputColorSpace: THREE.SRGBColorSpace 
        }}
      >
        <Scene mode={mode} />
      </Canvas>
      
      {/* UI Overlay */}
      <div style={{
        position: 'absolute',
        bottom: '50px',
        left: '50%',
        transform: 'translateX(-50%)',
        textAlign: 'center',
        pointerEvents: 'none',
        zIndex: 10
      }}>
        <h1 style={{
          fontFamily: '"Cinzel", serif',
          color: CONFIG.COLORS.GOLD,
          fontSize: '2rem',
          marginBottom: '1rem',
          textShadow: '0 0 10px rgba(255, 215, 0, 0.5)',
          letterSpacing: '5px',
          fontWeight: 300,
          opacity: 0.9
        }}>
          ARIX SIGNATURE
        </h1>
        <button 
          onClick={toggleMode}
          style={{
            pointerEvents: 'auto',
            background: 'rgba(0, 20, 10, 0.6)',
            border: `1px solid ${CONFIG.COLORS.GOLD}`,
            color: CONFIG.COLORS.GOLD,
            padding: '15px 40px',
            fontSize: '1rem',
            fontFamily: '"Montserrat", sans-serif',
            textTransform: 'uppercase',
            letterSpacing: '2px',
            cursor: 'pointer',
            backdropFilter: 'blur(5px)',
            transition: 'all 0.3s ease',
            outline: 'none',
            boxShadow: '0 0 20px rgba(0,0,0,0.5)'
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.background = CONFIG.COLORS.GOLD;
            e.currentTarget.style.color = '#000';
            e.currentTarget.style.boxShadow = '0 0 30px rgba(255, 215, 0, 0.6)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.background = 'rgba(0, 20, 10, 0.6)';
            e.currentTarget.style.color = CONFIG.COLORS.GOLD;
            e.currentTarget.style.boxShadow = '0 0 20px rgba(0,0,0,0.5)';
          }}
        >
          {mode === 'SCATTERED' ? 'Assemble' : 'Scatter'}
        </button>
      </div>

      <div style={{
          position: 'absolute',
          top: '30px',
          left: '30px',
          color: 'rgba(255,255,255,0.3)',
          fontFamily: 'sans-serif',
          fontSize: '0.8rem',
          pointerEvents: 'none'
      }}>
          INTERACTIVE CHRISTMAS TREE
      </div>
    </div>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
